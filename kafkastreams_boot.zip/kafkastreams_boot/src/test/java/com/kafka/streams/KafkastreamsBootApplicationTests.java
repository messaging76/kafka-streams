package com.kafka.streams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkastreamsBootApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.kafka.streams.timestamp;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kafka.streams.model.value.ValueElement;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.streams.processor.TimestampExtractor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

@Component
public class Extractor implements TimestampExtractor {


    @Override
    public long extract(ConsumerRecord<Object, Object> consumerRecord, long l) {
        long timestamp = Instant.now().toEpochMilli();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            //System.out.println("in try block" + (String) consumerRecord.value());
            ValueElement e = objectMapper.readValue((String)consumerRecord.value(),ValueElement.class);
           // System.out.println(e.getTimeStamp());
            timestamp = df.parse(e.getTimeStamp()).getTime();
            //System.out.println("epcho millis" + Long.toString(timestamp));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return timestamp ;
    }
}

package com.kafka.streams.model.value;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValueElement{

	@JsonProperty("timeStamp")
	private String timeStamp;

	@JsonProperty("dataElement1")
	private String dataElement1;

	@JsonProperty("dataElement2")
	private String dataElement2;

	public void setTimeStamp(String timeStamp){
		this.timeStamp = timeStamp;
	}

	public String getTimeStamp(){
		return timeStamp;
	}

	public void setDataElement1(String dataElement1){
		this.dataElement1 = dataElement1;
	}

	public String getDataElement1(){
		return dataElement1;
	}

	public void setDataElement2(String dataElement2){
		this.dataElement2 = dataElement2;
	}

	public String getDataElement2(){
		return dataElement2;
	}

	@Override
 	public String toString(){
		return 
			"ValueElement{" + 
			"timeStamp = '" + timeStamp + '\'' + 
			",dataElement1 = '" + dataElement1 + '\'' + 
			",dataElement2 = '" + dataElement2 + '\'' + 
			"}";
		}
}
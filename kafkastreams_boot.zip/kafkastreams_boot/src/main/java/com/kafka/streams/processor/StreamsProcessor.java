package com.kafka.streams.processor;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.Date;

@Component
public class StreamsProcessor {

    private static final Serde<String> STRING_SERDE = Serdes.String();
    @Autowired
    void buildPipeline(StreamsBuilder streamsBuilder) {
        KStream<String, String> messageStream = streamsBuilder.stream("streams_poc", Consumed.with(STRING_SERDE, STRING_SERDE));
        Duration windowSize = Duration.ofMinutes(1);
        Duration gracePeriod = Duration.ofMinutes(0);
        KStream<Windowed<String>, String> grouped = messageStream.groupByKey()
                .windowedBy(TimeWindows.ofSizeWithNoGrace(windowSize))
                .reduce((oldValue, newValue) -> {return newValue;})
                .suppress(Suppressed.untilWindowCloses(Suppressed.BufferConfig.unbounded()))
                .toStream()
                .peek((windowedKey, s) -> {
                    System.out.println(windowedKey.key());
                    Date date = new Date(windowedKey.window().endTime().getEpochSecond()*1000);
                    DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    System.out.println(df.format(date));
                    System.out.println("value json" + s);
                });

    }
}

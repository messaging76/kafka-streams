package com.kafka.streams.controller;

import com.kafka.streams.model.PublishMessage;
import com.kafka.streams.model.value.ValueElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@RestController
public class PublishController {

    @Autowired
    KafkaTemplate<String,ValueElement> producer;

    @PostMapping("/publishMessage")
    public String publish(@RequestBody PublishMessage message){
       try{
           //System.out.println(message.getKey());
           //System.out.println(message.getValue());
           SendResult<String, ValueElement> streams_poc = producer.send("streams_poc", message.getKey(), message.getValue()).get();
           System.out.println(streams_poc.getRecordMetadata().offset());
       }catch (Exception e){
           e.printStackTrace();
           return "publish failed";
       }
        return "SUCCESS";
    }
    @GetMapping("/publishMessage")
    public PublishMessage getSample(){
        ValueElement ve = new ValueElement();
        ve.setDataElement1("testElement1");
        ve.setDataElement2("testElement2");
        ve.setTimeStamp(Long.toString(Instant.now().toEpochMilli()));
        return new PublishMessage("key",ve);
    }
}

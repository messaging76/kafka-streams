package com.kafka.streams.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kafka.streams.model.value.ValueElement;

public class PublishMessage{

	@JsonProperty("value")
	private ValueElement value;

	@JsonProperty("key")
	private String key;
	public PublishMessage(String key, ValueElement value){
		this.key=key;
		this.value=value;
	}

	public void setValue(ValueElement value){
		this.value = value;
	}

	public ValueElement getValue(){
		return value;
	}

	public void setKey(String key){
		this.key = key;
	}

	public String getKey(){
		return key;
	}
}